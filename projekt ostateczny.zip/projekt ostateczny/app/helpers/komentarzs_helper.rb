module KomentarzsHelper
end
