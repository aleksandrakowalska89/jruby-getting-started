class KomentarzsController < ApplicationController
  before_action :set_komentarz, only: [:show, :edit, :update, :destroy]

  # GET /komentarzs
  # GET /komentarzs.json
  def index
    @komentarzs = Komentarz.all
  end

  # GET /komentarzs/1
  # GET /komentarzs/1.json
  def show
  end

  # GET /komentarzs/new
  def new
    @komentarz = Komentarz.new
  end

  # GET /komentarzs/1/edit
  def edit
  end

  # POST /komentarzs
  # POST /komentarzs.json
  def create
    @komentarz = Komentarz.new(komentarz_params)

    respond_to do |format|
      if @komentarz.save
        format.html { redirect_to @komentarz, notice: 'Komentarz został dodany.' }
        format.json { render :show, status: :created, location: @komentarz }
      else
        format.html { render :new }
        format.json { render json: @komentarz.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /komentarzs/1
  # PATCH/PUT /komentarzs/1.json
  def update
    respond_to do |format|
      if @komentarz.update(komentarz_params)
        format.html { redirect_to @komentarz, notice: 'Komentarz został edytowany.' }
        format.json { render :show, status: :ok, location: @komentarz }
      else
        format.html { render :edit }
        format.json { render json: @komentarz.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /komentarzs/1
  # DELETE /komentarzs/1.json
  def destroy
    @komentarz.destroy
    respond_to do |format|
      format.html { redirect_to komentarzs_url, notice: 'Komentarz został usunięty.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_komentarz
      @komentarz = Komentarz.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def komentarz_params
      params.require(:komentarz).permit(:imie, :data, :opis, :email)
    end
end
