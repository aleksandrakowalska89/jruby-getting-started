class WarsztatiesController < ApplicationController
   before_action :set_warsztaty, only: [:show, :edit, :update, :destroy]
  before_action :check_logged_in, :only => [:new, :create]
  
def check_logged_in
authenticate_or_request_with_http_basic("Ads") do |username, password|
username == "admin" && password == "admin"
end
end
  
  def index
    @warsztaties = Warsztaty.all
  end

  def new
    @warsztaty = Warsztaty.new
  end

  def create
warsztaty_parmas = params.require(:warsztaty).permit(:nazwa, :data,
:cena, :opis)
@warsztaty = Warsztaty.new(warsztaty_parmas)
if @warsztaty.save
flash[:komunikat] = 'Warsztat został poprawnie stworzony.'
redirect_to "/warsztaties/#{@warsztaty.id}"
else
render 'new'
end
end

    
  end
  def show
  end
  
   private
    # Use callbacks to share common setup or constraints between actions.
    def set_warsztaty
      @warsztaty = Warsztaty.find(params[:id])
    end
  
   def warsztaty_params
      params.require(:warsztaty).permit(:nazwa, :data, :cena, :opis)
    end

