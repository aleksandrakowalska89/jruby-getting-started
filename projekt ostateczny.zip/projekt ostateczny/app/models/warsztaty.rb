class Warsztaty < ActiveRecord::Base
    validates :nazwa, :presence => true
  validates :opis, :presence => true
  validates :cena, :presence => true
end
