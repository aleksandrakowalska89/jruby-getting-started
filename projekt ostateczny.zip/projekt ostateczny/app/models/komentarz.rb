class Komentarz < ActiveRecord::Base
  validates :imie, :presence => true
  validates :opis, :presence => true
end
