require 'test_helper'

class KomentarzTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
