require 'test_helper'

class WarsztatyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
