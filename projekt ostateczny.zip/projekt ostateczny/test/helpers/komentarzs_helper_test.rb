require 'test_helper'

class KomentarzsHelperTest < ActionView::TestCase
end
