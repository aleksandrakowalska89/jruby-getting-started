require 'test_helper'

class WarsztatiesHelperTest < ActionView::TestCase
end
