require 'test_helper'

class KomentarzsControllerTest < ActionController::TestCase
  setup do
    @komentarz = komentarzs(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:komentarzs)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create komentarz" do
    assert_difference('Komentarz.count') do
      post :create, komentarz: { data: @komentarz.data, email: @komentarz.email, imie: @komentarz.imie, opis: @komentarz.opis }
    end

    assert_redirected_to komentarz_path(assigns(:komentarz))
  end

  test "should show komentarz" do
    get :show, id: @komentarz
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @komentarz
    assert_response :success
  end

  test "should update komentarz" do
    patch :update, id: @komentarz, komentarz: { data: @komentarz.data, email: @komentarz.email, imie: @komentarz.imie, opis: @komentarz.opis }
    assert_redirected_to komentarz_path(assigns(:komentarz))
  end

  test "should destroy komentarz" do
    assert_difference('Komentarz.count', -1) do
      delete :destroy, id: @komentarz
    end

    assert_redirected_to komentarzs_path
  end
end
