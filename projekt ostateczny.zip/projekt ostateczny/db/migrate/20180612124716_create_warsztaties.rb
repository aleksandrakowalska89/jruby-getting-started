class CreateWarsztaties < ActiveRecord::Migration
  def change
    create_table :warsztaties do |t|

      t.string :nazwa
      t.date :data
      t.decimal :cena
      t.text :opis
      
      t.timestamps
    end
  end
end
