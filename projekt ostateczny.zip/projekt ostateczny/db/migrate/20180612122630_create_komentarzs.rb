class CreateKomentarzs < ActiveRecord::Migration
  def change
    create_table :komentarzs do |t|
      t.string :imie
      t.string :data
      t.text :opis
      t.string :email

      t.timestamps
    end
  end
end
